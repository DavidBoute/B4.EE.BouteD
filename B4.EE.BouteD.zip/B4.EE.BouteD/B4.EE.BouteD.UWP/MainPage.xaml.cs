﻿namespace B4.EE.BouteD.UWP
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();
            LoadApplication(new B4.EE.BouteD.App());
        }
    }
}
